pub fn add(left: usize, right: usize) -> usize {
    left + right
}


use std::thread;
use std::time::Duration;
//use rppal::gpio::Gpio;



fn blink() {

//let gpio = Gpio::new().unwrap();
//let mut pin = gpio.get(4).unwrap().into_output();
println!("{}","This is hello from Rust an real time");
//loop {
//pin.set_high();
//thread::sleep(Duration::from_millis(5));
//pin.set_low();

}
#[no_mangle]
pub extern "C" fn rust_function() {
    blink();
}
#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn it_works() {
        let result = add(2, 2);
        assert_eq!(result, 4);
    }
}

