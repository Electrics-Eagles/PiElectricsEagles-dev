The dev docs folder
There are all docs needed for drone development
Include the API and all others diagrams.

API Level Explain - explains different levels of the code developed and was can access by user.
