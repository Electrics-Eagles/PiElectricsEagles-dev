cargo doc --no-deps --open
#Graph
cargo deps | dot -Tpng > graph.png