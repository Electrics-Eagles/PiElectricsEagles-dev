sudo  cp pielectricseagles /run/media/alexfedora/rootfs/usr/bin/pielectricseagles
