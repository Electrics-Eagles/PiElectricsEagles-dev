python3 install.py
./install.sh
