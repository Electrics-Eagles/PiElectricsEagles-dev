*по возможности НИКОГДА не выключайте малинку просто обрубив питание. Микро-SD карточки, на которых записана система очень чувствительны к такого рода стрессам, будут ошибки и бэд-блоки на диске, а то и вовсе полетит система. Именно поэтому, если что-то получилось сделать — советую делать бекап образа, чтобы в случае такой поломки из него можно было восстановить и перезаписать образ системы


1. https://habr.com/ru/post/253159/
2. https://habr.com/ru/post/400011/
3. https://github.com/judge0/ide
4. https://github.com/lobodol/drone-flight-controller
5. https://habr.com/ru/company/rostelecom/blog/570098/
6. https://cdn.sparkfun.com/datasheets/Sensors/Accelerometers/RM-MPU-6000A.pdf
7. https://github.com/Seeed-Studio/Grove_6Axis_Accelerometer_And_Gyroscope_BMI088/blob/master/BMI088.h
8. https://blog.drogue.io/mpu-6050/
9. https://docs.rs/mpu9250-dmp/1.0.0/mpu9250_dmp/struct.Mpu9250.html
10. https://elvistkf.wordpress.com/2016/04/19/arduino-implementation-of-filters/
11. https://supuntharanga.blogspot.com/2014/04/accelerometer-data-filtering-using-low.html?m=1
12. https://docs.rust-embedded.org/book/intro/index.html
13. https://rust-lang-nursery.github.io/rust-cookbook/
14. https://doc.rust-lang.org/stable/book/
15. https://m.habr.com/ru/post/433624/



